<?php

$conn=mysqli_connect('127.0.0.1','u493935503_simon_hage','Dolores1!','u493935503_building','3306') or die('Database Connection Error');

?>