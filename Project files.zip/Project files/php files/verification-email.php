<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./css/bootstrap.min.css">
    <link rel="stylesheet" href="./css/style.css">
    <title>Document</title>
</head>
<body>
    <h3 class="text-center mt-5 mb-4 ml-auto">A Verification Email has been sent to your provided
    email. Please verify your email.
    </h3>
</body>
</html>