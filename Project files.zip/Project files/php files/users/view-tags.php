<?php
 session_start();
 if(!isset($_SESSION['company_email'])){
     header('Location: ../company-login.php');
 }
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/style.css">
    <title>Document</title>
  </head>
  <body>
  <?php include('navbar.php') ?>
  <?php
  include('../dbconfig.php');
  $query="select building.building_number,building.building_name,qr_codes.qr_type,qr_codes.qr_status,qr_codes.qr_invoice
  from qr_codes inner join building
  on qr_codes.building_number=building.building_number
  order by building.building_number;";
  $result=mysqli_query($conn,$query);
  if(mysqli_num_rows($result) > 0 ){
    ?>
      <h1 class="text-center text-color mt-4 mb-4">Tags</h1>
    <div class="container">
        <div class="row">
            <div class="col-11 m-auto custom">
                <table style="width: 100%;">
                    <thead>
                      <tr>
                        <th>Building Number</th>
                        <th>Building Name</th>
                        <th>Unit</th>
                        <th>Status</th>
                        <th>Invoice</th>
                      </tr>
                    </thead>
                    <tbody>
                    <?php
      while($row=mysqli_fetch_array($result,MYSQLI_NUM)){
            ?>
                      <tr>
                      <td><?php echo $row[0] ?></td>
                  <td><?php echo $row[1] ?></td>
                  <td><?php echo $row[2] ?></td>
                  <td><?php echo $row[3] ?></td>
                        <td>
                            <?php if($row[4] && $row[3] != 'active') {
                                ?> <a class="btn btn-outline-success" href="<?php echo $row[4] ?>" download="<?php echo basename($row[4]) ?>">Download</a>
                                
                         <?php   }?>
                            
                        </td>
                      </tr>
                      <?php    
      } ?>
                    </tbody>
                  </table>
            </div>
        </div>
    </div>
    <?php
  }else{
    echo "<p class='text-center alert alert-danger mt-5'>No Records</p>";
  }
  ?>
  </body>
</html>