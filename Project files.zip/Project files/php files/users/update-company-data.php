<?php
session_start();
if (!isset($_SESSION['company_email'])) {
    header('Location: ../company-login.php');
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register</title>
    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/style.css">
</head>

<body>
    <?php include('navbar.php') ?>
    <h1 style="color:#5c34c2 ;" class="text-center  mb-5 mt-5">Edit Company Data</h1>
    <?php
    include('../dbconfig.php');
    if (isset($_POST['u_button'])) {
        $c_name = mysqli_real_escape_string($conn, $_POST['c_name']);
        $m_name = mysqli_real_escape_string($conn, $_POST['m_name']);
        $c_email = $_SESSION['company_email'];
        $c_password = mysqli_real_escape_string($conn, $_POST['c_password']);
        $c_cpassword = mysqli_real_escape_string($conn, $_POST['c_cpassword']);
        $c_address = mysqli_real_escape_string($conn, $_POST['c_address']);
        $c_phone = mysqli_real_escape_string($conn, $_POST['c_phone']);
        $c_city = mysqli_real_escape_string($conn, $_POST['c_city']);
        $c_state = mysqli_real_escape_string($conn, $_POST['c_state']);
        $c_code = mysqli_real_escape_string($conn, $_POST['c_code']);
        if ($c_password == $c_cpassword) {
            $c_password = sha1($c_password);
            $query="update company set company_name='{$c_name}',company_manager='{$m_name}',company_phone='{$c_phone}',company_city='{$c_city}',
            company_state='{$c_state}',company_postcode='{$c_code}',company_password='{$c_password}' where company_email='{$c_email}'";
            $result=mysqli_query($conn,$query);
            if($result){
                echo "<p class='text-center alert alert-danger mt-5'>Data Updated Successfully</p>";
            }
        } else {
            echo "<p class='text-center alert alert-danger mt-5'>Passwords Does Not Match!</p>";
        }
    }

    ?>
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-6 m-lg-auto col-md-8 m-md-auto col-sm-10 m-sm-auto">
                <form method="post" action="update-company-data.php">
                    <div class="mb-3">
                        <label for="name">Company Name</label>
                        <input type="text" class="form-control" name="c_name">
                    </div>
                    <div class="mb-3">
                        <label for="name">Manager Name</label>
                        <input type="text" class="form-control" name="m_name">
                    </div>
                    <div class="mb-3">
                        <label for="password">Password</label>
                        <input type="password" class="form-control" name="c_password" required>
                    </div>
                    <div class="mb-3">
                        <label for="cpassword">Confirm Password</label>
                        <input type="password" class="form-control" name="c_cpassword" required>
                    </div>
                    <div class="mb-3">
                        <label for="address">Address</label>
                        <input type="text" class="form-control" name="c_address" >
                    </div>
                    <div class="mb-3">
                        <label for="phone">Phone</label>
                        <input type="tel" class="form-control" name="c_phone">
                    </div>
                    <div class="mb-3">
                        <label for="address">City</label>
                        <input type="text" class="form-control" name="c_city" >
                    </div>
                    <div class="mb-3">
                        <label for="address">State</label>
                        <input type="text" class="form-control" name="c_state" >
                    </div>
                    <div class="mb-3">
                        <label for="address">Postal Code</label>
                        <input type="text" class="form-control" name="c_code">
                    </div>
                    <div class="row">
                        <div class="col-3 ml-auto mr-auto mb-5 mt-4">
                            <button style="padding: 5px 30px;" class="custom-btns" type="submit" name="u_button">Update</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>


</body>

</html>