<?php
session_start();
if (!isset($_SESSION['company_email'])) {
  header('Location: ../company-login.php');
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css">
  <link rel="stylesheet" href="../css/bootstrap.min.css">
  <link rel="stylesheet" href="../css/style.css">
  <title>Document</title>
</head>

<body>
  <?php include('navbar.php') ?>
  <?php
  include('../dbconfig.php');
  $query = "select * from building";
  $result = mysqli_query($conn, $query);
  if (mysqli_num_rows($result) > 0) {
  ?>
    <h1 style="color: #5c34c2;" class="text-center mb-4 mt-4">Buildings</h1>
    <div class="container">
      <div class="row">
        <div class="col-12 m-auto custom">
          <table style="width: 100%;">
            <thead>
              <tr>
                <th>Building Number</th>
                <th>Building Name</th>
                <th>Address</th>
                <th>Status</th>
                <th>Invoice</th>
                <th>Remove</th>
                <th>View Record</th>
              </tr>
            </thead>
            <tbody>
              <?php
              while ($row = mysqli_fetch_assoc($result)) {
              ?>
                <tr>
                  <td><?php echo $row['building_number'] ?></td>
                  <td><?php echo $row['building_name'] ?></td>
                  <td><?php echo $row['building_address'] ?></td>
                  <td><?php echo $row['building_status'] ?></td>
                  <td>
                    <?php if ($row['building_status'] != 'active') {
                    ?> <a class="btn btn-outline-info" href="<?php echo $row['building_invoice'] ?>" download="<?php echo basename($row['building_invoice']) ?>">Download</a>
                    <?php } ?>
                  </td>
                  <td class="text-center">
                    <a style="cursor: pointer;" id="btn" data-number="<?php echo $row['building_number'] ?>"><i class="text-danger fas fa-trash-alt"></i></a>
                  </td>
                  <td>
                    <?php if ($row['building_status'] == 'active') {
                    ?> <a class="btn btn-outline-info" target="_blank" href="<?php echo './building-data.php?b_number=' . $row['building_number'] ?>">View</a>
                    <?php } ?>
                  </td>
                </tr>
              <?php
              } ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  <?php
  } else {
    echo "<p class='text-center alert alert-danger mt-5'>No Records<br>Register Building</p>";
  }
  ?>
  <script src="../js/jquery.min.js"></script>
  <script>
    $(() => {
      $(document).on("click","#btn", function(){
        var r = confirm("Are You Sure You want to delete this Building!");
        if (r == true) {
          let b_number = $(this).data('number');
          let element=this;
          $.ajax({
            url: 'remove-building.php',
            type: 'POST',
            data: {b_number},
            success: function(data){
              if(data == 1){
                $(element).closest("tr").fadeOut();
              }else{
                alert("Can't Delete Record.");
              }
            }
          })
        } else {
          alert("You pressed Cancel!. Building is Not deleted.");
        }
      })
    })
  </script>
</body>

</html>