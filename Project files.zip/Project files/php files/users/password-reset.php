
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/style.css">
    <title>Document</title>
</head>
<body>
<?php
        include('../dbconfig.php');
        $password = mysqli_real_escape_string($conn, $_POST['c_password']);
        $cpassword = mysqli_real_escape_string($conn, $_POST['c_cpassword']);
        $email = mysqli_real_escape_string($conn, $_POST['email']);
        $token = mysqli_real_escape_string($conn, $_POST['token']);
        if ($password == $cpassword) {
            $password=sha1($password);
            $query = "select * from company where company_email='{$email}' AND token='{$token}'";
            $result = mysqli_query($conn, $query);
            if (mysqli_num_rows($result) > 0) {
                $query = "update company set company_password='{$password}',token='' where company_email='{$email}'";
                $result = mysqli_query($conn, $query);
                if ($result) {
                    header('Location: ../company-login.php');
                }
            }else{
                echo "<p class='text-center alert alert-danger mt-5'>Error!</p>";
            }
}else{
    echo "<p class='text-center alert alert-danger mt-5'>Error!</p>";
}

?>
</body>
</html>