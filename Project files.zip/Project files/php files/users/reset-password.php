<?php
    function redirect()
    {
        header('Location: ../register-company.php');
    }
    if (!isset($_GET['email']) && !isset($_GET['token'])) {
        redirect();
    }
    ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/style.css">
</head>

<body>

    <h1 class="text-center mb-md-5 mb-sm-4 mt-5 text-color">Reset Password</h1>
    <div class="container">
        <div class="row">
            <div class="col-lg-6 m-lg-auto col-md-8 m-md-auto col-sm-10 m-sm-auto">
                <form method="post" action="password-reset.php">
                <input type="text" name="token" hidden value="<?php echo $_GET['token'] ?>">
                <input type="text" name="email" hidden value="<?php echo $_GET['email'] ?>">
                    <div class="mb-3">
                        <label>Password</label>
                        <input type="password" class="form-control" name="c_password" id="password"  required>
                    </div>
                    <div class="mb-3">
                        <label>Confirm Password</label>
                        <input type="password" class="form-control" name="c_cpassword" id="cpassword"  required>
                    </div>
                    <div class="row">
                        <div class="col-4 ml-auto mr-auto mb-5 mt-4">
                            <button style="padding: 5px 30px;" class="custom-btns" type="submit" name="reset-button" id="reset-button">Reset</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</body>

</html>