<?php
 session_start();
 if(!isset($_SESSION['company_email'])){
     header('Location: ../company-login.php');
 }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/style.css">
    <title>Document</title>
</head>
<body>
    <?php
    if(!isset($_GET['url'])){
        redirect('./building-registration.php');
    }
    $url=$_GET['url'];
    ?>
    <h4 class="text-center mt-5 ml-auto mr-auto ">Congratulations! Your Request is Submitted</h4>
    <h5 class="text-center mt-3 mb-5 ml-auto mr-auto ">You can download the invoice by clicking the link down below.</h5>
    <div class="row">
        <div class="col-sm-2 col-3 ml-auto mr-auto mb-5 mt-2">
            <a class="text-center custom-btns" href="<?php echo $url ?>" download="<?php echo basename($url) ?>">Download Invoice</a>
        </div>
    </div>
</body>
</html>