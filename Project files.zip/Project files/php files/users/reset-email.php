<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/style.css">
</head>

<body>
    <?php

    use PHPMailer\PHPMailer\PHPMailer;
    // use PHPMailer\PHPMailer\SMTP;
    use PHPMailer\PHPMailer\Exception;

    // Load Composer's autoloader
    require '../vendor/autoload.php';
    if (isset($_POST['reset-button'])) {
        include('../dbconfig.php');
        $c_email = mysqli_real_escape_string($conn, $_POST['c_email']);
        $sql = "select isConfirmed,token from company where company_email='{$c_email}'";
        $result = mysqli_query($conn, $sql);
        if (mysqli_num_rows($result) > 0) {
            $row = mysqli_fetch_assoc($result);
            if ($row['isConfirmed'] == 0) {
                echo "<p class='text-center alert alert-danger mt-5'>Email Not Verified</p>";
                $token=$row['token'];
                $mail=new PHPMailer();
                $mail->setFrom('register@virtualbuildingmanager.com');
                $mail->addAddress($c_email);
                $mail->Subject = "Verify Email";
                $mail->isHTML(true);
                $mail->Body = "Thank You for registering your company to the Virtual Building Manager system. Please check the link below to complete registration.<br>
                <a href='http://virtualbuildingmanager.com/confirm.php?email=$c_email&token=$token'>Verify<a/>";
                if($mail->send()){
                    echo "<p class='text-center alert alert-danger mt-5'>A verification Email sent to you</p>";
                }
            } else {
                $token = "asdfghjklpoiuytrewqzxcvbnmLKJHGFDSAQWERTYUIOPMNBVCXZ0987654321!$/()*";
                $token = str_shuffle($token);
                $token = substr($token, 0, 15);
                $query = "UPDATE company SET token='{$token}' where company_email='{$c_email}'";
                $result=mysqli_query($conn,$query);
                if ($result) {
                    $mail = new PHPMailer();
                    $mail->setFrom('register@virtualbuildingmanager.com');
                    $mail->addAddress($c_email);
                    $mail->Subject = "Reset Password";
                    $mail->isHTML(true);
                    $mail->Body = "Please click on the link below to reset your password: <br>
                <a href='http://virtualbuildingmanager.com/users/reset-password.php?email=$c_email&token=$token'>Reset Password<a/>";
                    if ($mail->send()) {
                        header('Location: reset-email-message.php');
                    }
                }
            }
        } else {
            echo "<p class='text-center alert alert-danger mt-5'>Email Does not Exist</p>";
        }
    }
    ?>
    <h1 class="text-center mb-md-5 mb-sm-5 mb-4 mt-5 text-color">Generate Reset Password Link</h1>
    <div class="container">
        <div class="row">
            <div class="col-lg-6 m-lg-auto col-md-8 m-md-auto col-sm-10 m-sm-auto">
                <form method="post" action="reset-email.php">
                    <div class="mb-3">
                        <label>Email</label>
                        <input type="email" class="form-control" name="c_email"  placeholder="Email" required>
                    </div>
                    <div class="row">
                        <div class="col-4 ml-auto mr-auto mb-5 mt-4">
                            <button style="width: 140px; padding: 5px 20px;" class="custom-btns" type="submit" name="reset-button">Send Email</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>


</body>

</html>