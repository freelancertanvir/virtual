<?php
session_start();
if (!isset($_SESSION['company_email'])) {
  header('Location: ../company-login.php');
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Register</title>
  <link rel="stylesheet" href="../css/bootstrap.min.css" />
  <link rel="stylesheet" href="../css/style.css">
</head>

<body>
  <?php include('navbar.php') ?>
  <h1 style="color: #5c34c2;" class="text-center mb-5 mt-5">Order More Tags</h1>
  <?php
  include('../dbconfig.php');
  require('../FPDF/fpdf.php');
  if (isset($_POST['o_button'])) {
    $c_email = $_SESSION['company_email'];
    $query = "select * from company where company_email='{$c_email}'";
    $result = mysqli_query($conn, $query);
    $row = mysqli_fetch_assoc($result);
    $b_number = mysqli_real_escape_string($conn, $_POST['b_number']);
    if (isset($_POST['qr_codes'])) {
        $qr = $_POST['qr_codes'];
    } else {
        $qr = $_POST['codelabel'];
    }
    $query = "select * from building where building_number='{$b_number}'";
    $result = mysqli_query($conn, $query);
    if (mysqli_num_rows($result) == 0) {
        echo "<p class='text-center alert alert-danger mt-5'>Building Does Not Exists</p>";
    } else {
        //A4 width : 219mm
        //default margin : 10mm each side
        //writable horizontal : 219-(10*2)=189mm
        $pdf = new FPDF('P', 'mm', 'A4');

        $pdf->AddPage();
        $row=mysqli_fetch_row($result);
        //set font to arial, bold, 14pt
        $pdf->SetFont('Arial', 'B', 28);
        $pdf->Cell(70, 5, '', 0, 0);
        $pdf->Cell(80, 5, 'INVOICE', 0, 1); //end of line
        $pdf->Cell(189, 6, '', 0, 1); //end of line
        //Cell(width , height , text , border , end line , [align] )
        $pdf->SetFont('Arial', '', 12);
        $pdf->Cell(130, 5, 'DNS Strata Services', 0, 0);
        $pdf->Cell(25, 5, 'Date', 0, 0);
        $date=date('d/m/Y');
        $pdf->Cell(34, 5, $date , 0, 1); //end of line

        $pdf->Cell(130, 5, 'PO BOX 650', 0, 0);
        $pdf->Cell(25, 5, 'invoice #', 0, 0);
        $invoice=uniqid();
        $pdf->Cell(34, 5, $invoice, 0, 1); //end of line

        $pdf->Cell(130, 5, 'Frenchs Forest NSW 2086', 0, 1);
        $pdf->Cell(130, 5, 'e: accounts@virtualbuildingmanager.com', 0, 1);
        $pdf->Cell(130, 5, 'a.b.n. 99 596 969 352', 0, 1);
        $pdf->Cell(189, 6, '', 0, 1); //end of line

        $pdf->Cell(30, 5, 'Bill to:', 0, 1); //end of line
        $pdf->Cell(60, 5, " ".$row[1], 0, 1); //end of line
        $pdf->Cell(90, 5, " ".$b_number, 0, 1); //end of line
        $pdf->Cell(130, 5, " ". $row[3], 0, 1); //end of line
        $pdf->Cell(130, 5, " ".$row[4] . " " . $row[5] . " " . $row[6], 0, 1); //end of line


        

        //invoice contents
        $pdf->SetFont('Arial', 'B', 14);
        $pdf->Cell(189, 6, '', 0, 1); //end of line
        $pdf->Cell(155, 5, 'Description', 1, 0);
        $pdf->Cell(34, 5, 'Amount', 1, 1,'C'); //end of line

        $pdf->SetFont('Arial', '', 12);

        //Numbers are right-aligned so we give 'R' after new line parameter
        
        // $pdf->Cell(155, 5, $b_name . " / " . $b_number, 1, 0);
        // $pdf->Cell(34, 5, '$110', 1, 1, 'C'); //end of line
        $total=0;
        if(strpos($qr,",")){
            $array=explode(",",$qr);
            for($i=0; $i<sizeof($array); $i++){
                $pdf->Cell(155, 5, "label - ".$array[$i], 1, 0);
                $pdf->Cell(34, 5, '$5.5', 1, 1, 'C'); //end of line
                $total=$total+5.5;
            }
        }else{
            $pdf->Cell(155, 5, $qr, 1, 0);
            $pdf->Cell(34, 5, '$5.5', 1, 1, 'C'); //end of line
            $total=$total+5.5;
        }
        $pdf->Cell(130	,5,'',0,0);
        $pdf->Cell(25	,5,'Total Due',0,0);
        $pdf->Cell(4	,5,'$',1,0);
        $pdf->Cell(30	,5,"$".$total,1,1,'C');//end of line
        $pdf->Cell(189, 6, '', 0, 1); //end of line
        $pdf->Cell(189, 6, '', 0, 1); //end of line
        $pdf->Cell(189, 6, '', 0, 1); //end of line
        $pdf->Cell(189, 6, '', 0, 1); //end of line
        $pdf->Cell(189, 6, '', 0, 1); //end of line
        $pdf->Cell(130, 5, 'PAYMENT INSTRUCTIONS', 0, 1);
        $pdf->Cell(180, 5, 'Post Cheque or money order to: PO Box 6250 Frenchs Forest NSW 2086', 0, 1);
        $pdf->Cell(130, 5, 'EFT : Account Name - DNS Strata Services', 0, 1);
        $pdf->Cell(10, 5, '', 0, 0);
        $pdf->Cell(60, 5, " BSB : 302-162", 0, 1);
        $pdf->Cell(10, 5, '', 0, 0);
        $pdf->Cell(60, 5, " Account # 126620-7", 0, 1);
        $pdf->Cell(189, 6, '', 0, 1); //end of line
        $pdf->Cell(180, 5, 'remittance to: accounts@virtualbuildingmanager.com', 0, 1);
        $pdf->Cell(189, 6, '', 0, 1); //end of line
        $pdf->Cell(130, 5, 'Thank you for your order', 0, 1);
        
        $filename = "../invoices-qrcodes/invoice-qr-codes-".$b_number .".pdf";
        $pdf->Output($filename, 'F');
        $match=uniqid();
        $query = "insert into qr_codes values('{$b_number}','{$qr}','inactive','{$filename}',1,'{$match}')";
        $result = mysqli_query($conn, $query);
        if ($result) {
            header("Location: new-tags-order.php?url=$filename");
        } else {
            echo 'Error';
            die();
        }
    }
}
  ?>
  <div class="container-fluid">
    <div class="row">
      <div class="col-lg-6 m-lg-auto col-md-8 m-md-auto col-sm-10 m-sm-auto">
        <form method="post" action="order-more-tags.php">
          <div class="mb-3">
            <label for="name">Building Number</label>
            <input type="text" class="form-control" name="b_number" required />
            <label>Format: DPxx.. or SPxx..</label>
          </div>
          <div class="form-check mb-2">
            <input class="form-check-input" type="radio" name="codelabel" id="label1" value="Generic" checked>
            <label class="form-check-label" for="label1">
              Single Tag for the whole Building
            </label>
          </div>
          <div class="form-check mb-3">
            <input class="form-check-input" type="radio" name="codelabel" id="label2">
            <label class="form-check-label" for="label2">
              Multiple Tags for different Units within a Building
            </label>
          </div>
          <div id="qrcodes"></div>

          <div class="row">
            <div class="col-4 ml-auto mr-auto mb-5 mt-4">
              <button class="text-center custom-btns" type="submit" name="o_button">Create Invoice</button>
            </div>
          </div>
        </form>
      </div>
    </div>
  </div>
  <script src="../js/jquery.min.js"></script>
  <script>
    var i = 0;
    $(() => {
      $('#label1').click(function() {
        if ($('#label1').is(':checked')) {
          $('#qrcodes').empty();
        }
      });
      $('#label2').click(function() {
        if ($('#label2').is(':checked')) {
          $('#qrcodes').empty();
          $('#qrcodes').append("<div class='mb-4'><label>Units</label><input type='text' class='form-control' id='qr_codes' name='qr_codes' required><label>Enter Different Units separating them with comma</label></div>")
        }
      });
    })
  </script>
</body>

</html>